package DsaProject;
import java.util.Scanner;

class Nodee {
    int data;
    Nodee next;
    Nodee prev;

    Nodee(int value) {
        data = value;
        next = null;
        prev = null;
    }
}

class DoublyLinkedList {
    static Nodee head; 

    DoublyLinkedList() {
        head = null;
    }

    static void insertAtBeginning(int value) {
        Nodee newNode = new Nodee(value);
        newNode.next = head;
        newNode.prev = null;

        if (head != null) {
            head.prev = newNode;
        }

        head = newNode;
    }

    static void insertAtEnd(int value) {
        Nodee newNode = new Nodee(value);

        if (head == null) {
            head = newNode;
            return;
        }

        Nodee current = head;
        while (current.next != null) {
            current = current.next;
        }

        current.next = newNode;
        newNode.prev = current;
    }

    static void insertInMiddle(int value, int position) {
        int count = countNodes();

        if (count == 0) {
            System.out.println("LIST IS EMPTY,MIDDLE NOT FOUND");
            System.out.println("RETURNING.....");
            return;
        }

        if (position < 1) {
            System.out.println("INVALID POSITION");
            System.out.println("RETURNING.....");
            return;
        }

        Nodee newNode = new Nodee(value);

        if (head == null || position == 1) {
            newNode.next = head;
            newNode.prev = null;

            if (head != null) {
                head.prev = newNode;
            }

            head = newNode;
            return;
        }

        Nodee current = head;
        for (int i = 1; i < position - 1 && current != null; ++i) {
            current = current.next;
        }

        if (current == null) {
            System.out.println("LINKEDLIST IS EMPTY,MIDDLE NOT FOUND");
            System.out.println("RETURNING.....");
            return;
        }

        newNode.next = current.next;
        newNode.prev = current;
        current.next = newNode;

        if (newNode.next != null) {
            newNode.next.prev = newNode;
        }
    }

    static void insertAtExactPosition() {
        if (head == null) {
            System.out.println("THE LINKEDLIST IS EMPTY");
            return;
        } else {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the value to insert: ");
            int valueExact = scanner.nextInt();
            Nodee newNode = new Nodee(valueExact);
            System.out.print("Enter the position of the node: ");
            int targetBefore = scanner.nextInt();

            if (targetBefore == 1) {
                newNode.next = head;
                newNode.prev = null;

                if (head != null) {
                    head.prev = newNode;
                }

                head = newNode;
                return;
            }

            int count = 0;
            Nodee current = head;
            while (current != null) {
                current = current.next;
                count++;
            }
            if (targetBefore > count || targetBefore <= 0) {
                System.out.println("INSERTION POSITION NOT VALID");
                return;
            }

            current = head;
            for (int i = 1; i < targetBefore - 1 && current != null; ++i) {
                current = current.next;
            }

            newNode.next = current.next;
            newNode.prev = current;
            current.next = newNode;

            if (newNode.next != null) {
                newNode.next.prev = newNode;
            }
        }
    }

    static void insertBeforePosition() {
        if (head == null) {
            System.out.println("THE LINKEDLIST IS EMPTY");
            return;
        } else {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the value to insert: ");
            int valueBefore = scanner.nextInt();
            Nodee newNode = new Nodee(valueBefore);
            System.out.print("Enter the position of the node before which to insert: ");
            int targetBefore = scanner.nextInt();

            if (targetBefore == 1) {
                newNode.next = head;
                newNode.prev = null;

                if (head != null) {
                    head.prev = newNode;
                }

                head = newNode;
                return;
            }

            int count = 0;
            Nodee current = head;
            while (current != null) {
                current = current.next;
                count++;
            }
            if (targetBefore > count || targetBefore <= 0) {
                System.out.println("INSERTION POSITION NOT VALID");
                return;
            }

            current = head;
            for (int i = 1; i < targetBefore - 1 && current != null; ++i) {
                current = current.next;
            }

            newNode.next = current.next;
            newNode.prev = current;
            current.next = newNode;

            if (newNode.next != null) {
                newNode.next.prev = newNode;
            }
        }
    }

    static void insertAfterPosition() {
        

        if (head == null) {
            System.out.println("THE LINKEDLIST IS EMPTY");
            return;
        } else {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the value to insert: ");
            int valueAfter = scanner.nextInt();
            Nodee newNode = new Nodee(valueAfter);
            System.out.print("Enter the position of the node after which to insert: ");
            int targetAfter = scanner.nextInt();
            int count = 0;
            Nodee current = head;
            while (current != null) {
                current = current.next;
                count++;
            }
            if (targetAfter > count || targetAfter <= 0) {
                System.out.println("INSERTION POSITION NOT VALID ");
                return;
            }

            current = head;
            for (int i = 1; i < targetAfter && current != null; ++i) {
                current = current.next;
            }

            newNode.next = current.next;
            newNode.prev = current;
            current.next = newNode;

            if (newNode.next != null) {
                newNode.next.prev = newNode;
            }
        }
    }

    static void deleteFirstNode() {
        if (head == null) {
            System.out.println("LINKEDLIST IS EMPTY");
            System.out.println("RETURNING.....");
            return;
        }

        head = head.next;

        if (head != null) {
            head.prev = null;
        }
    }

    static void deleteLastNode() {
        if (head == null) {
            System.out.println("LINKEDLIST IS EMPTY");
            System.out.println("RETURNING.....");
            return;
        }

        if (head.next == null) {
            head = null;
            return;
        }

        Nodee current = head;
        while (current.next.next != null) {
            current = current.next;
        }

        current.next = null;
    }

    static void deleteAtPosition(int position) {
        if (position < 1) {
            System.out.println("INVALID POSITION");
            return;
        }

        if (head == null) {
            System.out.println("LINKEDLIST IS EMPTY");
            return;
        }

        if (position == 1) {
            head = head.next;

            if (head != null) {
                head.prev = null;
            }
            return;
        }

        Nodee current = head;
        for (int i = 1; i < position - 1 && current != null; ++i) {
            current = current.next;
        }

        if (current == null || current.next == null) {
            System.out.println("INVALID POSITION");
            return;
        }

        current.next = current.next.next;

        if (current.next != null) {
            current.next.prev = current;
        }
    }

    static int countNodes() {
        int count = 0;
        Nodee current = head;

        while (current != null) {
            count++;
            current = current.next;
        }

        return count;
    }

  

    static void display() {
        Nodee current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
