package DsaProject;
import java.util.Scanner;

class Node {
    int data;
    Node next;

    Node(int value) {
        data = value;
        next = null;
    }
}

class LinkedList {
    static Node head; 

    LinkedList() {
        head = null;
    }

static void insertAtBeginning(int value) {
        Node newNode = new Node(value);
        newNode.next = head;
        head = newNode;
    }

static void insertAtEnd(int value) {
        Node newNode = new Node(value);

        if (head == null) {
            head = newNode;
            return;
        }

        Node current = head;
        while (current.next != null) {
            current = current.next;
        }

        current.next = newNode;
    }

static  void insertInMiddle(int value, int position) {
        int count = countNodes();
        
        if (count == 0) {
            System.out.println("LIST IS EMPTY,MIDDLE NOT FOUND");
            System.out.println("RETURNING.....");
            return;
        }

        if (position < 1) {
            System.out.println("INVALID POSITION");
            System.out.println("RETURNING.....");
            return;
        }

        Node newNode = new Node(value);

        if (head == null || position == 1) {
            newNode.next = head;
            head = newNode;
            return;
        }

        Node current = head;
        for (int i = 1; i < position - 1 && current != null; ++i) {
            current = current.next;
        }

        if (current == null) {
            System.out.println("LINKEDLIST IS EMPTY,MIDDLE NOT FOUND");
            System.out.println("RETURNING.....");
            return;
        }

        newNode.next = current.next;
        current.next = newNode;
    }
     static void insertAtExactPosition() {

    if (head == null) {
        System.out.println("THE LINKEDLIST IS EMPTY");
        return;
    }
    else{
        Scanner scanner =new Scanner(System.in);
        System.out.print("Enter the value to insert: ");
        int Value = scanner.nextInt();
        Node newNode = new Node(Value);

    System.out.print("Enter the position of the node: ");
     int targetBefore = scanner.nextInt();

    if (targetBefore == 1) {
        newNode.next = head;
        head = newNode;
        return;
    }
    int count=0;
    Node Current=head;
    while(Current!=null){
        Current=Current.next;
        count++;
    }
    if(targetBefore>count || targetBefore<=0){
        System.out.println("INSERTION POSITION NOT VALID");
        return;
    }

    Node current = head;
    for (int i = 1; i < targetBefore - 1 && current != null; ++i) {
        current = current.next;
    }

    newNode.next = current.next;
    current.next = newNode;
}
}
    static void insertBeforePosition() {

    if (head == null) {
        System.out.println("THE LINKEDLIST IS EMPTY");
        return;
    }
    else{
        Scanner scanner =new Scanner(System.in);
        System.out.print("Enter the value to insert: ");
        int Value = scanner.nextInt();
        Node newNode = new Node(Value);
    System.out.print("Enter the position of the node before which to insert: ");
     int targetBefore = scanner.nextInt();

    if (targetBefore == 1) {
        newNode.next = head;
        head = newNode;
        return;
    }
    int count=0;
    Node Current=head;
    while(Current!=null){
        Current=Current.next;
        count++;
    }
    if(targetBefore>count || targetBefore<=0){
        System.out.println("INSERTION POSITION NOT VALID");
        return;
    }

    Node current = head;
    for (int i = 1; i < targetBefore - 1 && current != null; ++i) {
        current = current.next;
    }

    newNode.next = current.next;
    current.next = newNode;
}
}
static void insertAfterPosition() {

    if (head == null) {
        System.out.println("THE LINKEDLIST IS EMPTY");
        return;
    }
    else{
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the value to insert: ");
        int valueAfter = scanner.nextInt();
        Node newNode = new Node(valueAfter);
        System.out.print("Enter the position of the node after which to insert: ");
        int targetAfter = scanner.nextInt();
       int count=0;
       Node Currentt=head;
       while(Currentt!=null){
        Currentt=Currentt.next;
        count++;
    }
    if(targetAfter>count || targetAfter<=0){
        System.out.println("INSERTION POSITION NOT VALID ");
        return;
    }

    Node current = head;
    for (int i = 1; i < targetAfter && current != null; ++i) {
        current = current.next;
    }

    newNode.next = current.next;
    current.next = newNode;
}
}

static void deleteFirstNode() {
        if (head == null) {
            System.out.println("LINKEDLIST IS EMPTY");
            System.out.println("RETURNING.....");
            return;
        }

        head = head.next;
    }

static void deleteLastNode() {
        if (head == null) {
            System.out.println("LINKEDLIST IS EMPTY");
            System.out.println("RETURNING.....");
            return;
        }

        if (head.next == null) {
            head = null;
            return;
        }

        Node current = head;
        while (current.next.next != null) {
            current = current.next;
        }

        current.next = null;
    }

static void deleteAtPosition(int position) {

        if (position < 1) {
            System.out.println("INVALID POSITION");
            return;
        }

        if (head == null) {
            System.out.println("LINKEDLIST IS EMPTY");
            return;
        }

        if (position == 1) {
            head = head.next;
            return;
        }

        Node current = head;
        for (int i = 1; i < position - 1 && current != null; ++i) {
            current = current.next;
        }

        if (current == null || current.next == null) {
            System.out.println("INVALID POSITION");
            return;
        }

        current.next = current.next.next;
    }
static int countNodes() {
        int count = 0;
        Node current = head;

        while (current != null) {
            count++;
            current = current.next;
        }

        return count;
    }

static void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

