package DsaProject;
import java.util.Scanner;

public class Main {
    static int MainChoice;
    static int ArrayChoice;
    static int StackChoice;
    static int QueueChoice;
    static int SearchChoice;
    static int LSearchChoice;
    static int BSearchChoice;
    static int SortChoice;
    static int SortChoiceA;
    static int SortChoiceD;
    static int LinearQueueChoice;
    static int CircularQueueChoice;
    static int LinkedListChoice;
    static int DoubleLinkedListChoice;
    static int SingleLinkedListChoice;
    static int SingleLinkedListInsertionChoice;
    static int SingleLinkedListDeletionChoice;
    static int DoubleLinkedListInsertionChoice;
    static int DoubleLinkedListDeletionChoice;
public static void main(String[] args) {

    Scanner sc =new Scanner(System.in);
    
    CallingFunction(sc);
}
static void CallingFunction(Scanner sc){

        System.out.print("\033[H\033[2J");
        System.out.println("DATA STRUCTURES AND ALGORITHMS");
        System.out.println("MADE BY: MALIK HAIDER HUSSAIN");
        System.out.println("TEACHER: NAUMAN QADEER");
        ArrayProject.ThreadFunction1();

    do{ 
    ArrayProject.ThreadFunction();
    ArrayProject.MainDisplay();
    MainChoice=sc.nextInt();
    switch(MainChoice){
    case 1:
    do{
        ArrayProject.ThreadFunction();
        boolean Value = false;
       for (int i = 0; i < ArrayProject.A.length; i++) {
        if (ArrayProject.A[i] != 0) {
            Value = true;
            break;
        }
        }
        if (Value) {} 
        else {
        System.out.println(
"NOTE: ARRAY IS EMPTY, ENTER AN ARRAY USING INSERTION FIRST IN ORDER TO PERFORM ANY OTHER ACTION!");
    }
       ArrayProject.ArrayDisplay();
       ArrayChoice =sc.nextInt();
       switch(ArrayChoice){
        case 1:
                ArrayProject.Traverse();
                break;
        case 2:
              ArrayProject.Insertion(sc,ArrayProject.k,ArrayProject.item);
                break;
        case 3:
             ArrayProject.Deletion(sc,ArrayProject.k);
               break;
        case 4:{
            do{
            ArrayProject.ThreadFunction();
            System.out.println("WHICH TYPE OF SEARCHING DO U WANT");
            System.out.println("1:LINEAR SEARCHING " + "\n2:BINARY SEARCHING \n3:EXIT");
            System.out.println("\nPRESS THE RELEVANT BUTTON FOR PROCESS");
            SearchChoice=sc.nextInt();
            switch (SearchChoice) 
            {
                case 1:{
                    do{
                   // System.out.print("\033[H\033[2J");
                   ArrayProject.ThreadFunction();
                    System.out.println("WHICH TYPE OF LINEAR SEARCH DO U WANT");
                    System.out.println("1:SINGLE LINEAR SEARCH " + "\n2:MULTIPLE LINEAR SEARCH \n3:EXIT");
                    System.out.println("\nPRESS THE RELEVANT BUTTON FOR PROCESS");
                    LSearchChoice=sc.nextInt();
                    switch (LSearchChoice)
                     {
                        case 1:
                            ArrayProject.SingleLinearSearch(sc,ArrayProject.item);
                            break;
                        case 2:
                            ArrayProject.MultipleLinearSearch(sc,ArrayProject.item);
                            break;
                        case 3:
                            System.out.println("\nRETURNING TO PREVIOUS STEP....");
                            break;
                        default:
                            System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                            break;
                    }
                }
                    while(LSearchChoice!=3);
                }
                break;
                    
                case 2:{
                    do{
                   // System.out.print("\033[H\033[2J");
                   ArrayProject.ThreadFunction();
                    System.out.println("WHICH TYPE OF BINARY SEARCH DO U WANT");
                    System.out.println("1:SINGLE BINARY SEARCH " + "\n2:MULTIPLE BINARY SEARCH \n3:EXIT");
                    System.out.println("\nPRESS THE RELEVANT BUTTON FOR PROCESS");
                    BSearchChoice=sc.nextInt();
                     switch(BSearchChoice)
                      {
                        case 1:
                           ArrayProject.SingleBinarySearch(sc,ArrayProject.item);
                           break;
                        case 2:
                           ArrayProject.MultiBinarySearch(sc,ArrayProject.item);
                           break;
                        case 3:
                           System.out.println("\nRETURNING TO PREVIOUS STEP....");
                           break;
                        default:
                           System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                           break;
                      }
                    }
                    while(BSearchChoice!=3);
                    }
                    break;
                case 3:
                    System.out.println("\nRETURNING TO PREVIOUS STEP....");
                    break;
                default:
                    System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                    break;
                }
                    }
                    while(SearchChoice!=3);
               }
                break;
                
                    
                
        case 5:{
        do{
            //System.out.print("\033[H\033[2J");
             ArrayProject.ThreadFunction();
             ArrayProject.SortingDisplay();
              SortChoice=sc.nextInt();
              switch(SortChoice)
              {
                case 1:
                    ArrayProject.Traverse();
                 break;
                case 2:{
                    do{
                    ArrayProject.ThreadFunction();
                    ArrayProject.ASortingDisplay();
                    SortChoiceA=sc.nextInt();
                    switch(SortChoiceA)
                    {
                        case 1:
                         ArrayProject.BubbleSortA(sc);
                        break;
                        case 2:
                         ArrayProject.SelectionSortA(sc);
                        break;
                        case 3:
                         ArrayProject.InsertionSortA();
                        break;
                        case 4:
                         ArrayProject.ShellSortA();
                        break;
                        case 5:
                         ArrayProject.mergeSortA(0, ArrayProject.N - 1);
                          if(ArrayProject.N!=0){
                          System.out.println();
                          System.out.println("THE ARRAY IS SORTED");
                          System.out.println("RETURNING.....");
                           }
                        break;
                        case 6:
                         ArrayProject.quickSortA(0,ArrayProject.N-1);
                         if(ArrayProject.N!=0){
                         System.out.println();
                         System.out.println("THE ARRAY IS SORTED");
                         System.out.println("RETURNING.....");
                         }
                        break;
                        case 7:
                         System.out.println("\nRETURNING TO PREVIOUS STEP....");
                        break;
                        default:
                         System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                        break;
                     }}
                     while(SortChoiceA!=7);
                    }
                break;
                case 3:{
                    do{
                    ArrayProject.ThreadFunction();
                    ArrayProject.DSortingDisplay();
                    SortChoiceD=sc.nextInt();
                    switch(SortChoiceD)
                    {
                        case 1:
                        ArrayProject.BubbleSortD(sc);
                        break;
                        case 2:
                        ArrayProject.SelectionSortD();
                        break;
                        case 3:
                        ArrayProject.InsertionSortD();
                        break;
                        case 4:
                        ArrayProject.ShellSortD();
                        break;
                        case 5:
                        ArrayProject.mergeSortD(0,ArrayProject.N-1);
                        if(ArrayProject.N!=0){
                        System.out.println();
                        System.out.println("THE ARRAY IS SORTED");
                        System.out.println("RETURNING.....");
                         }
                        break;
                        case 6:
                        ArrayProject.quickSortD(0,ArrayProject.N-1);
                        if(ArrayProject.N!=0){
                        System.out.println();
                        System.out.println("THE ARRAY IS SORTED");
                        System.out.println("RETURNING.....");
                         }
                        break;
                        case 7:
                         System.out.println("\nRETURNING TO PREVIOUS STEP....");
                        break;
                        default:
                         System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                        break;
                    }}
                    while(SortChoiceD!=7);
                }
                break;
                case 4:
                    System.out.println("\nRETURNING TO PREVIOUS STEP....");
                    break;
                default:
                    System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                    break;
              }}
              while(SortChoice!=4);
            }
                break;
        case 6:
        System.out.println("BACK TO MAIN MENU.....");
        break;
        default:
        System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
        break;       

    }

}
       while(ArrayChoice!=6);
       break;
    case 2:{
        Stack.Stackarray();
    do{
     ArrayProject.ThreadFunction();
      ArrayProject.StackDisplay();
      StackChoice=sc.nextInt();
      switch(StackChoice){
        case 1:
        Stack.traverse();
        break;
        case 2:
        Stack.push();
        break;
        case 3:
        Stack.pop();
        break;
        case 4:
        System.out.println("BACK TO MAIN MENU.....");
        break;
        default:
        System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
        break;
    }
       }
       while(StackChoice!=4);
    }break;
    case 3:{
    QueueArray.Queue();
    do{
      ArrayProject.ThreadFunction();
      ArrayProject.QueueDisplay();
      QueueChoice=sc.nextInt();
      switch(QueueChoice){
        case 1:{
        do{
            ArrayProject.ThreadFunction();
            ArrayProject.Simple_CircularQueueDisplay();
             LinearQueueChoice=sc.nextInt();
            switch(LinearQueueChoice){
                case 1:
                QueueArray.TRAVERSELQ();
                break;
                case 2:
                QueueArray.INSERTIONLQ();
                break;
                case 3:
                QueueArray.DELETIONLQ();
                break;
                case 4:
                System.out.println("RETURNING TO MENU...");
                break;
                default:
                System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                break;
            }
        }
            while(LinearQueueChoice!=4);

        }break;
        case 2:{
        do{
            ArrayProject.ThreadFunction();
            ArrayProject.Simple_CircularQueueDisplay();
             CircularQueueChoice=sc.nextInt();
            switch(CircularQueueChoice){
                case 1:
                QueueArray.TRAVERSECQ();
                break;
                case 2:
                QueueArray.INSERTIONCQ();
                break;
                case 3:
                QueueArray.DELETIONCQ();
                break;
                case 4:
                System.out.println("RETURNING TO MENU...");
                break;
                default:
                System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                break;
            }
        }
            while(CircularQueueChoice!=4);
    }
        break;
        case 3:
        System.out.println("BACK TO MAIN MENU.....");
        break;
        default:
        System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
        break;
    }
      
}
      while(QueueChoice!=3);
    }
      break;
      case 4:{  
        do{
        ArrayProject.ThreadFunction();
        ArrayProject.LinkedList();
        LinkedListChoice=sc.nextInt();
        switch(LinkedListChoice){
            case 1:{
                do{
             ArrayProject.ThreadFunction();
             ArrayProject.sll();
             SingleLinkedListChoice=sc.nextInt();
             switch(SingleLinkedListChoice){
                case 1:{
            do{
            ArrayProject.ThreadFunction();
            ArrayProject.sllInsertion();
            SingleLinkedListInsertionChoice=sc.nextInt();
            switch(SingleLinkedListInsertionChoice){
                case 1:
                System.out.print("INSERT VALUE AT BEGINNING: ");
                int valueBeginning = sc.nextInt();
                LinkedList.insertAtBeginning(valueBeginning);
                break;
                case 2:
                System.out.print("INSERT VALUE AT END: ");
                int valueEnd = sc.nextInt();
                LinkedList.insertAtEnd(valueEnd);
                break;
                case 3:
                System.out.print("INSERT VALUE AT MIDDLE ");
                int valueMiddle = sc.nextInt();
                int countt =LinkedList.countNodes();
                int mid=countt / 2 + 1;
                LinkedList.insertInMiddle(valueMiddle, mid);
                break;
                case 4:
                System.out.print("INSERT THE VALUE BEFORE MIDDLE: ");
                int valueBeforeMiddle = sc.nextInt();
                int Count =LinkedList.countNodes();
                int middlePosition = (Count / 2)+1;
                LinkedList.insertInMiddle(valueBeforeMiddle, middlePosition);
                break;
                case 5:
                System.out.print("INSERT THE VALUE AFTER MIDDLE: ");
                int valueAfterMiddle = sc.nextInt();
                int Countt =LinkedList.countNodes();
                int MiddlePosition = (Countt / 2)+1;
                LinkedList.insertInMiddle(valueAfterMiddle, MiddlePosition+ 1);
                break;
                case 6:
                LinkedList.insertAtExactPosition();
                break;
                case 7:
                LinkedList.insertBeforePosition();
                break;
                case 8:
                LinkedList.insertAfterPosition();
                break;
                case 9:
                System.out.print("LINKEDLIST: ");
                LinkedList.display();
                break;
                case 10:
                System.out.println("\nRETURNING TO PREVIOUS STEP....");
                break;
                default:
                System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                break;
            }}
            while(SingleLinkedListInsertionChoice!=10);
        }
            break;
                case 2:
                {
            do{
            ArrayProject.ThreadFunction();
            ArrayProject.sllDeletion();
            SingleLinkedListDeletionChoice=sc.nextInt();
            switch(SingleLinkedListDeletionChoice){
                case 1:
                LinkedList.deleteFirstNode();
                break;
                case 2:
                LinkedList.deleteLastNode();
                break;
                case 3:
                int positionToDelete = LinkedList.countNodes();
                int middle=positionToDelete / 2 + 1;
                LinkedList.deleteAtPosition(middle);
                break;
                case 4:
                System.out.println("ENTER THE POSITION TO DELETE");
                int deletePosition=sc.nextInt();
                LinkedList.deleteAtPosition(deletePosition);
                break;
                case 5:
                System.out.print("LINKEDLIST: ");
                LinkedList.display();
                break;
                case 6:
                System.out.println("\nRETURNING TO PREVIOUS STEP....");
                break;
                default:
                System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                break;
            }}
            while(SingleLinkedListDeletionChoice!=6);
        }
                break;
                case 3:
                System.out.println("\nRETURNING TO PREVIOUS STEP....");
                break;
                default:
                System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                break;
             }}
             while(SingleLinkedListChoice!=3);
        }
            break;
            case 2:{
             do{   
            ArrayProject.ThreadFunction();
            ArrayProject.dll();
            DoubleLinkedListChoice=sc.nextInt();
            switch(DoubleLinkedListChoice){
                case 1:{
            do{
            ArrayProject.ThreadFunction();
            ArrayProject.dllInsertion();
            DoubleLinkedListInsertionChoice=sc.nextInt();
            switch(DoubleLinkedListInsertionChoice){
                case 1:
                System.out.print("INSERT VALUE AT BEGINNING: ");
                int valueBeginningg = sc.nextInt();
                DoublyLinkedList.insertAtBeginning(valueBeginningg);
                break;
                case 2:
                System.out.print("INSERT VALUE AT END: ");
                int valueEndd = sc.nextInt();
                DoublyLinkedList.insertAtEnd(valueEndd);
                break;
                case 3:
                System.out.print("INSERT VALUE AT MIDDLE ");
                int valueMiddlee = sc.nextInt();
                int count = DoublyLinkedList.countNodes();
                int midd = count / 2 + 1;
                DoublyLinkedList.insertInMiddle(valueMiddlee, midd);
                break;
                case 4:
                System.out.print("INSERT THE VALUE BEFORE MIDDLE: ");
                int valueBeforeMiddle = sc.nextInt();
                int COUNT = DoublyLinkedList.countNodes();
                int middlePositionn = COUNT/ 2 + 1;
                DoublyLinkedList.insertInMiddle(valueBeforeMiddle , middlePositionn);
                break;
                case 5:
                System.out.print("INSERT THE VALUE AFTER MIDDLE: ");
                int valueAfterMiddle = sc.nextInt();
                int COUNTT = DoublyLinkedList.countNodes();
                int MiddlePositionn = COUNTT/ 2 + 1;
                DoublyLinkedList.insertInMiddle(valueAfterMiddle , MiddlePositionn+1);
                break;
                case 6:
                DoublyLinkedList.insertAtExactPosition();
                break;
                case 7:
                DoublyLinkedList.insertBeforePosition();
                break;
                case 8:
                DoublyLinkedList.insertAfterPosition();
                break;
                case 9:
                System.out.print("LINKEDLIST: ");
                DoublyLinkedList.display();
                break;
                case 10:
                System.out.println("\nRETURNING TO PREVIOUS STEP....");
                break;
                default:
                System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                break;
            }}
            while(DoubleLinkedListInsertionChoice!=10);
        }
                break;
                case 2:
                {
            do{
            ArrayProject.ThreadFunction();
            ArrayProject.dllDeletion();
            DoubleLinkedListDeletionChoice=sc.nextInt();
            switch(DoubleLinkedListDeletionChoice){
                case 1:
                DoublyLinkedList.deleteFirstNode();
                break;
                case 2:
                DoublyLinkedList.deleteLastNode();
                break;
                case 3:
                int positionToDelete = DoublyLinkedList.countNodes();
                int middle = positionToDelete / 2 + 1;
                DoublyLinkedList.deleteAtPosition(middle);
                break;
                case 4:
                System.out.println("ENTER THE POSITION TO DELETE");
                int deletePosition=sc.nextInt();
                DoublyLinkedList.deleteAtPosition(deletePosition);
                break;
                case 5:
                System.out.print("LINKEDLIST: ");
                DoublyLinkedList.display();
                break;
                case 6:
                System.out.println("\nRETURNING TO PREVIOUS STEP....");
                break;
                default:
                System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                break;
            }}
            while(DoubleLinkedListDeletionChoice!=6);
        }
                break;
                case 3:
                System.out.println("\nRETURNING TO PREVIOUS STEP....");
                break;
                default:
                System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
                break;
            }}
            while(DoubleLinkedListChoice!=3);
        }
            break;
            case 3:
            System.out.println("\nRETURNING TO PREVIOUS STEP....");
            break;
            default:
            System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
            break;
    
        }}
        while(LinkedListChoice!=3);
    }
        break;
    case 5:
    System.out.println("EXITING THE CODE......");
    return;
    default:
    System.out.println("\nINVALID CHOICE, PLEASE SELECT A VALID OPTION");
    break;
}
}
      while(MainChoice!=5);

}}
